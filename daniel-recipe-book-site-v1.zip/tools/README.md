# שכבת הייבוא — השלב הבא

האתר כבר בנוי כך שכל מתכון יכול לקבל:
- ingredients
- instructions
- extractionStatus
- extractionMessage

השלב הבא הוא לבנות importer נפרד שמקבל URL ומנסה:
1. JSON-LD / Recipe schema באתר רגיל.
2. OpenGraph ותיאור העמוד.
3. מקורות וידאו ציבוריים כאשר אפשר.
4. אם מקור חברתי חסום — מסלול חלופי בעזרת צילום מסך/קובץ שהמשתמש מספק.

האתר עצמו נשאר סטטי ומהיר; ה-importer יעדכן את data/recipes.js.
